function toggleZoomScreen() {
    var currentZoom = document.body.style.zoom;
    console.log(currentZoom);
}

Mousetrap.bind(['command+up', 'ctrl+up'], toggleZoomScreen);
Mousetrap.bind(['command+down', 'ctrl+down'], toggleZoomScreen);